const config = {
	port: 3000,
	database: {
		DATABASE: 'nodesql',
		USERNAME: 'root',
		PASSWORD: '123456',
		PORT: '3306',
		HOST: 'localhost'
	}
}

module.exports = config
