# koa-ejsblog

### Introduction:

A simple blog based on wclimb's tutorial -- [Github](https://github.com/wclimb/Koa2-blog)

Using Koa2, ejs and MySql.  Without test module...

```bash
$ mysql -u root -p
$ create database nodesql;
$ use nodesql;

$ npm i supervisor -g
$ npm i
$ supervisor index.js
```

### Requirements:

- config-lite
- ejs
- koa
- koa-bodyparser
- koa-mysql-session
- koa-router
- koa-session-minimal
- koa-static
- koa-static-cache
- koa-views
- markdown-it
- md5
- moment
- mysql

### Todo:

- The project is incomplete. Many things need to do.